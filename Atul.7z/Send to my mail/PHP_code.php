<?php
// Fetching Values From URL

	$id2 = $_POST['username'];
	$name2 = $_POST['name1'];
	$email2 = $_POST['email1'];
	$age2 = $_POST['msg'];
	
	$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
	$db = mysql_select_db("myDB", $connection); // Selecting Database,in may case myDB is the name of the database.

	if (isset($_POST['id1'])) {
	//Insert Query
	$query = mysql_query("insert into emp_table(id,name,dept,email,age,sal) values ('id2','$name2','$dept','$email2','$age2','$sal2')"); 
	echo "Form Submitted succesfully";
	}
	mysql_close($connection); // Connection Closed
?>
