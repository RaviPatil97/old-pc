?php

$username = "username"; 
$password = "password"; 
$database = "register"; 

$mysqli = new mysqli("localhost", $username, $password, $database);
$result = mysqli_query($con,"SELECT * FROM register");

echo "<table border='1'>
<tr>
<th>Name</th>
<th>Email</th>
<th>Message</th>
<th>Country</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['Name'] . "</td>";
echo "<td>" . $row['Email'] . "</td>";
echo "<td>" . $row['Message'] . "</td>";
echo "<td>" . $row['Country'] . "</td>";
echo "</tr>";
}
echo "</table>";

mysqli_close($con);
?>