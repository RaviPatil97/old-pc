<?php
 
// $name = $_GET["name"];
// $servername = "localhost";
// $username = "username";
// $password = "password";
// $db = "student";

 // Create connection
// $conn = new mysqli($servername, $username, $password,$student);
// $string = sprintf("SELECT $name FROM users WHERE name = '$name'");
// $query = msql_query($string);
// if($query == false) {
	
// } else {
    // echo("Yes");
// }
$id = $_POST["id"];
$id1 = array(10,11,12);
if(in_array(id1,id)){
	echo("error");
}
	else{
		echo("success")
}
    

?>