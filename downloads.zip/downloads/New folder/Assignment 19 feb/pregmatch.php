<?php
$id = $name = $email = $dept = $doj = $age = $sal = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["id"])) {
   echo "ID is required";
  } else {
    $id = test_input($_POST["id"]);
    if (!preg_match(" /^\d+$/",$id)) {
      echo "Only numbers are allowed"; 
    }
  }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    echo "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      echo  "Only letters and white space allowed"; 
    }
  }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["email"])) {
    echo "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    if (!preg_match(" /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,})$/",$email)) {
      echo "Not in proper format"; 
    }
  }


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["dept"])) {
    echo "Department is required";
  } else {
    $dept = test_input($_POST["dept"]);
    if (!preg_match("/^[a-zA-Z ]*$/",$dept)) {
      echo "Only letters and white space allowed"; 
    }
  }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["joining"])) {
    echo "Joining Date is required";
  } else {
    $doj = test_input($_POST["joining"]);
    if (!preg_match(" ~^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2}))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$~",$doj));
 {
      echo "Improper Date"; 
    }
  }


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["age"])) {
    echo "Age is required";
  } else {
    $age = test_input($_POST["age"]);
    if (!preg_match(" /^\d+$/",$age)) {
      echo "Only numbers are allowed"; 
    }
  }


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["sal"])) {
    echo "Salary is required";
  } else {
    $age = test_input($_POST["age"]);
    if (!preg_match(" /^\d+$/",$id)) {
      echo "Only numbers are allowed"; 
    }
  }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


echo "<h2>Employee Details:</h2>";

echo $id;
echo "<br>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $dept;
echo "<br>";
echo $doj;
echo "<br>";
echo $age;
echo $sal;
echo "<br>";
?>


