
function checkId() {
var id = document.getElementById("id").value;;

$.ajax({
	url: "check.php",
   method: "POST",
   data: {id: id},
   success: function(response) { 
        $('#msg').html(response);
    }
   
});
}

