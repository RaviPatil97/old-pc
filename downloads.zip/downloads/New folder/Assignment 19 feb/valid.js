function validateForm() {
  var a = document.forms["myForm"]["id"].value;
  if (a == "") {
    alert("ID must be filled out");
    return false;
  }

  var b = document.forms["myForm"]["name"].value;
  if (b == "") {
    alert("Name must be filled out");
    return false;
  }
   var c = document.forms["myForm"]["email"].value;
  if (c == "") {
    alert("Email must be filled out");
    return false;
  }
   var d = document.forms["myForm"]["dept"].value;
  if (d == "") {
    alert("Department must be filled out");
    return false;
  }
   var e = document.forms["myForm"]["joining"].value;
  if (e == "") {
    alert("Date of Joining must be filled out");
    return false;
  }
   var f = document.forms["myForm"]["age"].value;
  if (f == "") {
    alert("Age must be filled out");
    return false;
  }
   var g = document.forms["myForm"]["salary"].value;
  if (g == "") {
    alert("Salary must be filled out");
    return false;
  }
}