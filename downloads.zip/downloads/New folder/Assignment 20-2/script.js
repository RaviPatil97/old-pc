function myFunction() {

	var id = document.getElementById("id").value;
	var name = document.getElementById("name").value;
	var dept = document.getElementById("dept").value;
	var email = document.getElementById("email").value;
	var age = document.getElementById("age").value;
	var sal = document.getElementById("sal").value;

		// Returns successful data submission message when the entered information is stored in database.

	var dataString = 'id1=' + id + '&name1=' + name +'&dept1=' + dept + '&email1=' + email + '&age1=' + age +'&sal1=' + sal;


	if (id == '' ||name == '' ||dept == '' || email == '' || age == '' ||sal == '') {
	alert("Please Fill All Fields");
	} else {
	// AJAX code to submit form.
	$.ajax({
	type: "POST",
	url: "PHP_code.php",
	data: dataString,
	cache: false,
	success: function(html) {
	alert(html);
	}
	});
	}
	return false;

}
