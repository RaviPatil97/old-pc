$(document).ready(function(){

$("#form1").Submit({
   rules: {
     field1: "required"
   },
   messages: {
     field1: "Please specify your name"

   }
})

$('#btn').click(function() {
 $("#form1").Submit();  // This is not working and is not validating the form
});

});